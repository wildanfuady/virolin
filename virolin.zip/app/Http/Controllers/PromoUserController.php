<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Promo;

class PromoUserController extends Controller
{
    public function index(Request $request)
    {
        $now = date('Y-m-d');
        $paginate= 10;
        $data['promos'] = Promo::where('promo_status', 'Active')->where('promo_start', '>=', $now)->where('promo_end', '<=', $now)->paginate($paginate);
        return view('promo.user.index', $data)->with('i', ($request->input('page', 1) - 1) * $paginate);
    }
}
