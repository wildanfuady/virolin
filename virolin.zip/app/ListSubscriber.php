<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ListSubscriber extends Model
{
    protected $table="list_subscribers";
    protected $primaryKey="list_sub_id";
}
