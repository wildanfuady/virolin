<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Landingpage extends Model
{
    protected $table = "landingpages";
    protected $primaryKey = "lp_id";
}
