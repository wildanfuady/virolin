<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=9" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <script src="{{ asset('landingpage/content') }}/js/jquery.min.js"></script>
    <link href="{{ asset('landingpage/content') }}/css/bootstrap.min.css" rel="stylesheet" />
    <link href="{{ asset('landingpage/content') }}/css/bonus.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" type="text/css" />
    <link rel="stylesheet" href="{{ asset('landingpage/content') }}/css/timer.css" type="text/css" />
    <script src="{{ asset('landingpage/content') }}/js/custom.js"></script>
    <title>Virolin - Manage Database in Simple Ways </title>
</head>
<body>
    <div class="banner">
        <div class="container">
            <div class="col-md-6 col-md-push-3 text-center">
                <div class="">
                    <h1 class="md22 sm30 xs25 w600 white top1 text-center">
                        Terima kasih sudah mengisi form
                    </h1>
                </div>
            </div>
            <div class="clearfix"></div>
          
            <div class="col-md-10 col-md-offset-1 text-center">
                <br>
                <h3 class="md45 sm20 xs20 lh120 yellow w600">
                    Silahkan cek kotak masuk / spam email Anda dan dapatkan free ecourse meningkatkan jumlah lead 10x lebih cepat dan efektif. <br><br>Kami telah mengirim Akses nya via email<br>
                </h3>
            </div>
            <div class="clearfix"></div>
            <div class="text-center">
                <p class="md25 sm18 xs18 lh120  white">
             
                </p>
            </div>
            <div class="clearfix"></div>
            <div class="col-md-9 col-md-push-1 col-sm-10 col-xs-12 col-xs-offset-0 ml5 mt1">
               

            </div>

        </div>
        <div class="clearfix"></div>
        <div class="container">
            <div class="text-center">
                <p class="md25 sm20 xs20 lh120 white mt2 w600 mb-1">
                
                </p>
				 <p class="md25 sm20 xs20 lh120 white mt2 w600 mb-1">
             
                </p>
            </div>

         <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 bonusbutton mt1">
                   
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12 col-xs-12 col-sm-7 mt2">
                    
                </div>
            </div>
        </div>
    </div>
		
    <div class="strip_footer clear">
        <div class="container">
            <div class=" white">
                <div class="col-md-12 col-sm-12 col-xs-12 md15 sm14 xs11 text-center">
                    <a href="#" target="_blank"> CopyRight 2020 @ Virolin.Com</a>
                   

                </div>
            </div>
        </div>
    </div>

</body>
</html>