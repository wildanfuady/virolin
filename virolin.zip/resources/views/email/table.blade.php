<table border='1'>
    <tr>
        <th>No</th>
    </tr>
    <tr>
        <td>{{$productName}}</td>
    </tr>
</table>