<footer class="main-footer">
    <div class="float-right d-none d-sm-inline">
        This Website Made With <i class="fa fa-heart" style="color:red"></i> From Bogor
    </div>
    <strong>Copyright &copy; {{ date('Y') }} <a href="https://virolin.ilmucoding.com">Virolin</a>.</strong> All rights reserved.
</footer>