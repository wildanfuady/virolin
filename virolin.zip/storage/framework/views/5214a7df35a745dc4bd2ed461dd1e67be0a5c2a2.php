<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.mainmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--================================-->
<!-- Page Inner Start -->
<!--================================-->
<div class="page-inner">
    <!-- Main Wrapper -->
    <div id="main-wrapper">
        <div class="pageheader pd-t-25 pd-b-35">
            <div class="pd-t-5 pd-b-5">
            <h1 class="pd-0 mg-0 tx-20">Create Campaign</h1>
            </div>
            <div class="breadcrumb pd-0 mg-0">
            <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>"><i class="icon ion-ios-home-outline"></i> Home</a>
            <a class="breadcrumb-item" href="">Campaign</a>
            </div>
        </div>

        <div class="row row-xs clearfix">
            <div class="col-md-12 col-lg-12 mb-5">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-header-title">
                            List Campaign
                        </h4>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('landingpage-create')): ?>
                            <a class="btn btn-info btn-sm float-right" href="<?php echo e(route('campaign.create')); ?>"> Create New Campaign</a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php
                            if($msg_success = Session::get('success')){
                                $class = "alert alert-success alert-dismissable";
                                $msg = $msg_success;
                            } else if($msg_info = Session::get('info')){
                                $class = "alert alert-info alert-dismissable";
                                $msg = $msg_info;
                            } else if($msg_warning = Session::get('warning')){
                                $class = "alert alert-warning alert-dismissable";
                                $msg = $msg_warning;
                            } else {
                                $class = "d-none";
                                $msg = "";
                            }
                        ?>
                        <div class="<?php echo e($class); ?>" id="alert-msg">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php echo e($msg); ?>

                        </div>
                        <div class="row mt-3 mb-3">
                            <div class="col-md-10">
                                <div class="form-group">
                                    <?php echo e(Form::text('search', $keyword, ['class' => 'form-control', 'placeholder' => 'Cari judul campaign ...', 'id' => 'search'])); ?>

                                </div>
                            </div>
                            <div class="col-md-2">
                                <button id="btn-search" class="btn btn-primary btn-block">Seacrh</button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="table_id">
                                <thead>
                                    <tr>
                                        <th width="1%">No</th>
                                        <th>Name</th>
                                        <th>View</th>
                                        <th>Created Date</th>
                                        <th width="150px" class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $campaign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e(++$i); ?></td>
                                        <td><?php echo e($item->campaign_name); ?></td>
                                        <td><?php echo e($item->campaign_form_view); ?></td>
                                        <td><?php echo e(date('d-m-Y H:i', strtotime($item->created_at))); ?></td>
                                        <td class="text-center">
                                            <div class="btn-group">
                                                <a class="btn btn-light btn-sm" href="<?php echo e(url($item->campaign_slug)); ?>" target="_blank"><i class="fa fa-eye"></i></a>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('landingpage-edit')): ?>
                                                <a class="btn btn-light btn-sm" href="<?php echo e(route('campaign.edit', $item->campaign_id)); ?>"><i class="fa fa-edit"></i></a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('landingpage-delete')): ?>
                                                <a class="btn btn-light btn-sm" href="<?php echo e(url('campaign/destroy/'.$item->campaign_id)); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');"><i class="fa fa-trash"></i></a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($campaign->appends($_GET)->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    $(document).ready(function() {

        $("#search").keypress(function(event){
            if(event.keyCode == 13) { // kode enter
                filter();
            }
        });

        $("#btn-search").click(function(event){
            filter();
        });

        var filter = function(){
            var keyword = $("#search").val();
            console.log(keyword);

            window.location.replace("<?php echo e(url('landingpages')); ?>?keyword=" + keyword);
        }
    });

</script>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  <?php /**PATH D:\laragon\www\virolin\resources\views/campaign/index.blade.php ENDPATH**/ ?>