<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.mainmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-inner">
    <div id="main-wrapper">
        <div class="pageheader pd-t-25 pd-b-35">
            <div class="pd-t-5 pd-b-5">
            <h1 class="pd-0 mg-0 tx-20">My Subscribers</h1>
            </div>
            <div class="breadcrumb pd-0 mg-0">
            <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>"><i class="icon ion-ios-home-outline"></i> Home</a>
            <a class="breadcrumb-item" href="">My Subscribers</a>
            </div>
        </div>
        <div class="row row-xs clearfix">
            <div class="col-md-12 col-lg-12">
                <div class="card mg-b-20">
                    <div class="card-header">
                        <h4 class="card-header-title">
                            List All Subscriber
                        </h4>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mysubscriber-create')): ?>
                            <a class="btn btn-info btn-sm" href="<?php echo e(route('mysubscribers.create')); ?>"> Create List Subscriber</a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body pd-t-0 pd-b-20 collapse show" id="collapse3">
                        <?php
                            if($msg_success = Session::get('success')){
                                $class = "alert alert-success alert-dismissable";
                                $msg = $msg_success;
                            } else if($msg_info = Session::get('info')){
                                $class = "alert alert-info alert-dismissable";
                                $msg = $msg_info;
                            } else if($msg_warning = Session::get('warning')){
                                $class = "alert alert-warning alert-dismissable";
                                $msg = $msg_warning;
                            } else {
                                $class = "d-none";
                                $msg = "";
                            }
                        ?>
                        <div class="<?php echo e($class); ?> mt-3" id="alert-msg">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php echo e($msg); ?>

                        </div>
                        <div class="row mt-3 mb-3">
                            <div class="col-md-10">
                                <div class="form-group">
                                    <?php echo e(Form::text('search', $keyword, ['class' => 'form-control', 'placeholder' => 'Cari judul group ...', 'id' => 'search'])); ?>

                                </div>
                            </div>
                            <div class="col-md-2">
                                <button id="btn-search" class="btn btn-primary btn-block">Seacrh</button>
                            </div>
                        </div>
                        <table class="table table-hover table-responsive-sm table-bordered">
                            <thead>
                                <tr>
                                    <th width="1%">No</th>
                                    <th>Group</th>
                                    <th>Total Subscriber</th>
                                    <th>Created Date</th>
                                    <th>Status</th>
                                    <th width="150px" class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $mysubscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e(++$i); ?></td>
                                    <td><?php echo e($item->list_sub_name); ?></td>
                                    <td>
                                    <?php

                                    $jumlah_sub = DB::table('subscribers')->where('user_id', $item->user_id)->where('list_sub_id', $item->list_sub_id)->where('subscriber_status', 'valid')->count();
                                    echo $jumlah_sub;

                                    ?>
                                    </td>
                                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($item->created_at))); ?></td>
                                    <td><?php echo e($item->list_sub_status); ?></td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <a class="btn btn-light btn-sm" href="<?php echo e(route('mysubscribers.show',$item->list_sub_id)); ?>"><i class="fa fa-eye"></i></a>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mysubscriber-edit')): ?>
                                            <a class="btn btn-light btn-sm" href="<?php echo e(route('mysubscribers.edit',$item->list_sub_id)); ?>"><i class="fa fa-edit"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mysubscriber-delete')): ?>
                                            <a class="btn btn-light btn-sm" href="<?php echo e(url('mysubscriber/destroy/'.$item->list_sub_id)); ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');"><i class="fa fa-trash"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($mysubscribers->appends($_GET)->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    $(document).ready(function() {

        $("#search").keypress(function(event){
            if(event.keyCode == 13) { // kode enter
                filter();
            }
        });

        $("#btn-search").click(function(event){
            filter();
        });

        var filter = function(){
            var keyword = $("#search").val();
            console.log(keyword);

            window.location.replace("<?php echo e(url('mysubscribers')); ?>?keyword=" + keyword);
        }
    });

</script>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\virolin\resources\views/mysubscriber/index.blade.php ENDPATH**/ ?>