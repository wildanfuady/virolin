<!--================================-->
<!-- Page Sidebar Start -->
<!--================================-->
<div class="page-sidebar">
<div class="logo">
    <a class="logo-img" href="index.html">		
    <img class="desktop-logo" src="<?php echo e(asset('template/metrical')); ?>/images/logo-virolin-sidebar.png" alt="">
    <img class="small-logo" src="<?php echo e(asset('image/sidebar-virolin.jpg')); ?>" alt="">
    </a>			
    <i class="ion-ios-close-empty" id="sidebar-toggle-button-close"></i>
</div>
<!--================================-->
<!-- Sidebar Menu Start -->
<!--================================-->
<div class="page-sidebar-inner">
    <div class="page-sidebar-menu">
        <ul class="accordion-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard-admin')): ?>
            <li>
            <a href="<?php echo e(url('dashboard')); ?>"><i data-feather="home"></i>
                <span>Dashboard</span>
            </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard-user')): ?>
            <li>
            <a href="<?php echo e(url('home')); ?>"><i data-feather="home"></i>
                <span>Dashboard</span>
            </a>
            </li>
            <?php endif; ?>
            <?php if(Auth::user()->status == "valid" || Auth::user()->status = "Valid"): ?>
            <?php else: ?>
            <li class="open">
            <a href="<?php echo e(url('home')); ?>"><i data-feather="home"></i>
                <span>Dashboard</span>
            </a>
            </li>
            <?php endif; ?>
            <?php if(empty(Auth::user()->id)): ?>
              <!-- Null -->
            <?php else: ?>
                <?php 
                $data = DB::table('users')->where('id', Auth::user()->id)->first();
                ?>
                <?php if($data->status != "valid"): ?>
                <li class="open">
                    <a href="<?php echo e(url('home')); ?>"><i data-feather="home"></i>
                        <span>Dashboard <?php echo e($data->status); ?></span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('konfirmasi-pembayaran')); ?>"><i data-feather="dollar-sign"></i>
                    <span>Konfirmasi Pembayaran</span></a>
                </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
            <li>
            <a href="<?php echo e(route('roles.index')); ?>"><i data-feather="key"></i>
            <span>Role Permission</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users-list')): ?>
            <li>
            <a href="<?php echo e(route('users.index')); ?>"><i data-feather="users"></i>
            <span>Manage Customer</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('banks-list')): ?>
            <li>
            <a href="<?php echo e(route('banks.index')); ?>"><i data-feather="dollar-sign"></i>
            <span>Manage Bank</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('promos-list')): ?>
            <li>
            <a href="<?php echo e(route('promos.index')); ?>"><i data-feather="percent"></i>
            <span>Manage Promo</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orders-list')): ?>
            <li>
            <a href="<?php echo e(route('orders.index')); ?>"><i data-feather="shopping-cart"></i>
            <span>Manage Order</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payments-list')): ?>
            <li>
            <a href="<?php echo e(route('payment.index')); ?>"><i data-feather="send"></i>
            <span>Manage Payment</span><span class="badge badge-success ft-right count_payment">10+</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products-list')): ?>
            <li>
            <a href="<?php echo e(route('products.index')); ?>"><i data-feather="folder"></i>
            <span>Manage Product</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reports-list')): ?>
            <li>
            <a href="<?php echo e(route('reports.index')); ?>"><i data-feather="bar-chart"></i>
            <span>Manage Reports</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('landingpage-list')): ?>
            <li>
            <a href="<?php echo e(route('campaign.index')); ?>"><i data-feather="layers"></i>
            <span>Campaign</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mysubscriber-list')): ?>
            <li>
            <a href="<?php echo e(route('mysubscribers.index')); ?>"><i data-feather="users"></i>
            <span>Subscribers</span></a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report-user')): ?>
            <li>
            <a href="<?php echo e(url('report')); ?>"><i data-feather="file"></i>
            <span>Report</span><i class="accordion-icon fa fa-angle-left"></i></a>
            <ul class="sub-menu">
                <li><a href="<?php echo e(url('report/shares')); ?>">Shares</a></li>
                <li><a href="<?php echo e(url('report/payment')); ?>">Payment</a></li>
                <li><a href="<?php echo e(url('report/trafik')); ?>">Trafik</a></li>
            </ul>
            </li>
            <?php endif; ?>
            
        </ul>
    </div>
</div>
<!--/ Sidebar Menu End -->
<!--================================-->
<!-- Sidebar Footer Start -->
<!--================================-->
<div class="sidebar-footer">									
    <a class="pull-left" href="<?php echo e(url('profile')); ?>" data-toggle="tooltip" data-placement="top" data-original-title="Profile">
    <i data-feather="user" class="ht-15"></i></a>									
    <a class="pull-left " href="<?php echo e(url('report/payment')); ?>" data-toggle="tooltip" data-placement="top" data-original-title="Payment">
    <i data-feather="dollar-sign" class="ht-15"></i></a>
    <a class="pull-left" href="<?php echo e(url('promo')); ?>" data-toggle="tooltip" data-placement="top" data-original-title="Promo">
    <i data-feather="bell" class="ht-15"></i></a>
    <a class="pull-left" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" data-toggle="tooltip" data-placement="top" data-original-title="Sign Out">
    <i data-feather="log-out" class="ht-15"></i></a>
</div>
<!--/ Sidebar Footer End -->
</div>
<!--/ Page Sidebar End -->
<script>
$(document).ready(function() {
  
  // Get Jumlah Konfirmasi Pembayaran
  $.ajax({
    type : "GET",
    url  : '/payment/count_payment',
    dataType : "JSON",
    success: function (data) {
      $('.count_payment').html(data);
    }
  });
});
</script><?php /**PATH D:\laragon\www\virolin\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>