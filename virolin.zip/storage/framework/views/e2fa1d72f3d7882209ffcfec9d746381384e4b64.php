<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.mainmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-inner">
    <div id="main-wrapper">
        <div class="pageheader pd-t-25 pd-b-35">
            <div class="pd-t-5 pd-b-5">
            <h1 class="pd-0 mg-0 tx-20">Create Subscriber</h1>
            </div>
            <div class="breadcrumb pd-0 mg-0">
            <a class="breadcrumb-item" href="<?php echo e(url('/home')); ?>"><i class="icon ion-ios-home-outline"></i> Home</a>
            <a class="breadcrumb-item" href="">Create Subscriber</a>
            </div>
        </div>

        <div class="row row-xs clearfix">
            <div class="col-md-12 col-lg-12">
                <div class="card mg-b-20">
                    <?php echo e(Form::open(['url' => 'mysubscriber/new/store/'.$id])); ?>

                    <div class="card-header">
                        <h4 class="card-header-title">
                            Create New Subscriber
                        </h4>
                    </div>
                    <div class="card-body">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                        <?php echo e(Form::hidden('id', $id, ['class'=>'form-control'])); ?>

                        
                        <div class="form-group">
                        
                            <?php echo e(Form::label('sub_name', 'Name')); ?>

                            <?php echo e(Form::text('sub_name', '', ['class' => 'form-control', 'placeholder' => 'Enter Subscriber Name'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('sub_email', 'Email')); ?>

                            <?php echo e(Form::text('sub_email', '', ['class' => 'form-control', 'placeholder' => 'Enter Subscriber Email', 'type' => 'email'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('sub_hp', 'No Hp')); ?>

                            <?php echo e(Form::number('sub_hp', '', ['class' => 'form-control', 'placeholder' => '---- ---- ----'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('sub_alamat', 'Alamat')); ?>

                            <?php echo e(Form::textarea('sub_alamat', '', ['class' => 'form-control', 'placeholder' => 'Enter Subscriber Address'])); ?>

                        </div>

                        <div class="form-group">
                            <?php echo e(Form::label('sub_lp', 'Campaign')); ?>

                            <?php echo e(Form::select('sub_lp', $campaign, null, ['class' => 'form-control', 'placeholder' => 'Choose One'])); ?>

                        </div>
                        
                        <div class="form-group">

                            <?php echo e(Form::label('sub_status', 'Status')); ?>

                            <?php echo e(Form::select('sub_status', ['valid' => 'Valid', 'invalid' => 'Invalid'], null, ['class' => 'form-control', 'placeholder' => 'Choose One'])); ?>

                        </div>
                                
                    </div>
                    <div class="card-footer">
                        <a href="#" onclick="history.go(-1);" class="btn btn-outline-info">Back</a>
                        &nbsp;
                        &nbsp;
                        <button type="submit" class="btn btn-primary float-right">Simpan</button>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\virolin\resources\views/mysubscriber/create_subscriber.blade.php ENDPATH**/ ?>